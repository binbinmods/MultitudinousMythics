# 1.0.2

Fixed Essentials Compatibility (hopefully)

# 1.0.1

Fixed minor issue with dual class characters

# 1.0.0

Initial Release
